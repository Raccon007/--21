﻿namespace CourseWork.ViewModel
{
    public class MainVM : BaseVM
    {
       
    }
}
